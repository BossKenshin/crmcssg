-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2023 at 04:08 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crmcdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `stid` int(11) NOT NULL,
  `student_id_no` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `course_year` varchar(255) NOT NULL,
  `st_username` varchar(50) NOT NULL,
  `st_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`stid`, `student_id_no`, `firstname`, `lastname`, `email`, `gender`, `course_year`, `st_username`, `st_password`) VALUES
(1, '12315415', 'Nobita', 'Rimuru', 'noob@gmail.com', 'Male', 'BSIT 2nd Year', 'nEat2397', '2yDaV6jS'),
(2, '15546556', 'Nobito', 'Rimuru', 'nuub@gmail.com', 'Male', 'BSIT 3rd Year', 'pgxoc2Ey', 'NF1WDtyh'),
(3, '12315415', 'Nobita', 'Rimuru', 'noob@gmail.com', 'Male', 'BSIT 2nd Year', 'LZEEay9Z', 'sZHvz1kU'),
(4, '15546556', 'Nobito', 'Rimuru', 'nuub@gmail.com', 'Male', 'BSIT 3rd Year', 'nQmlyeCp', 'UQZg4iLU');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`stid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `stid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
