<?php
include 'dbconnect.php';

 

$fn = str_replace( "'" ,"''",htmlspecialchars($_GET['sfn']));
$ln = str_replace( "'" ,"''",htmlspecialchars($_GET['sln']));
$email = str_replace( "'" ,"''",htmlspecialchars($_GET['email']));
$sid = str_replace( "'" ,"''",htmlspecialchars($_GET['sid']));
$gender = str_replace( "'" ,"''",htmlspecialchars($_GET['gen']));
$cy = str_replace( "'" ,"''",htmlspecialchars($_GET['cny']));
$username = str_replace( "'" ,"''",htmlspecialchars($_GET['user']));
$pass = str_replace( "'" ,"''",htmlspecialchars($_GET['pass']));





$insert_student = "INSERT INTO `students`(`student_id_no`, `firstname`, `lastname`, `email`, `gender`, `course_year`, `st_username`, `st_password`)
                VALUES ('$sid', '$fn','$ln','$email','$gender','$cy','$username','$pass')";

$res = mysqli_query($conn,$insert_student);


if($res){
    echo "{\"res\" : \"success\"}";
}else{
   echo "{\"res\" : \"error\"}";
}

?>